#include "Akinator.h"
#include <iostream>
using namespace std;

int main(){
    Akinator ak;
    cout << "Think of one company from the list below:\n\n";

    string companies[50] = {
        // Tech (10)
        "Apple", "Samsung", "Google", "Microsoft", "Intel",
        "IBM", "Sony", "Dell", "Nvidia", "AMD",
        // Automobile (8)
        "Tesla", "Toyota", "BMW", "Ford", "Mercedes",
        "Honda", "Ferrari", "Volkswagen",
        // Beverage (6)
        "CocaCola", "Pepsi", "Starbucks", "RedBull", "Heineken", "Nescafe",
        // Sports & Apparel (6)
        "Nike", "Adidas", "Puma", "Reebok", "UnderArmour", "NewBalance",
        // Retail & E-Commerce (6)
        "Amazon", "Walmart", "IKEA", "Alibaba", "eBay", "Target",
        // Finance (6)
        "Visa", "Mastercard", "PayPal", "Goldman Sachs", "JPMorgan", "AmericanExpress",
        // Pharma (4)
        "Pfizer", "Johnson&Johnson", "Bayer", "Novartis",
        // Food (4)
        "McDonald's", "KFC", "Subway", "Nestle"
    };

    for(int i = 0; i < 50; i++)
        cout << i+1 << ". " << companies[i] << endl;
    cout << "\nPress Enter when ready...";
    cin.ignore();

    // Insert all leaf (answer) nodes
    for(int i = 0; i < 50; i++)
        ak.insert_answer(true, companies[i], nullptr, nullptr);

    // ============================================================
    // BOTTOM-UP TREE CONSTRUCTION
    // Rule: insert a node BEFORE any node that references it
    // Chain: Tech -> Auto -> Beverage -> Sports -> Retail -> Finance -> Pharma -> Food
    // Every category root: yes->sub-tree, no->next category
    // ============================================================

    // ===== FOOD BRANCH (deepest, no further chaining) =====
    ak.insert(false,"Is it a sandwich focused fast food chain?","Subway","Nestle");
    ak.insert(false,"Is it KFC?","KFC","Is it a sandwich focused fast food chain?");
    ak.insert(false,"Is it a burger chain?","McDonald's","Is it KFC?");
    ak.insert(false,"Is it food company?","Is it a burger chain?","Nestle");

    // ===== PHARMA BRANCH -> no chains to food =====
    ak.insert(false,"Is it American pharma company?","Pfizer","Johnson&Johnson");
    ak.insert(false,"Is it a European pharma company?","Bayer","Novartis");
    ak.insert(false,"Is it an American or European pharma company?","Is it American pharma company?","Is it a European pharma company?");
    ak.insert(false,"Is it pharma company?","Is it an American or European pharma company?","Is it food company?");

    // ===== FINANCE BRANCH -> no chains to pharma =====
    ak.insert(false,"Is it Visa or Mastercard?","Visa","Mastercard");
    ak.insert(false,"Is it a card network not a digital wallet?","Is it Visa or Mastercard?","PayPal");
    ak.insert(false,"Is it a payment company?","Is it a card network not a digital wallet?","AmericanExpress");
    ak.insert(false,"Is it Goldman Sachs?","Goldman Sachs","JPMorgan");
    ak.insert(false,"Is it a traditional investment bank?","Is it Goldman Sachs?","Is it a payment company?");
    ak.insert(false,"Is it finance company?","Is it a traditional investment bank?","Is it pharma company?");

    // ===== RETAIL BRANCH -> no chains to finance =====
    ak.insert(false,"Is it a Chinese e-commerce platform?","Alibaba","eBay");
    ak.insert(false,"Is it an online marketplace?","Amazon","Is it a Chinese e-commerce platform?");
    ak.insert(false,"Is it IKEA?","IKEA","Target");
    ak.insert(false,"Is it a physical retail store?","Walmart","Is it IKEA?");
    ak.insert(false,"Is it an online or physical retailer?","Is it an online marketplace?","Is it a physical retail store?");
    ak.insert(false,"Is it retail company?","Is it an online or physical retailer?","Is it finance company?");

    // ===== SPORTS BRANCH -> no chains to retail =====
    ak.insert(false,"Is it UnderArmour?","UnderArmour","NewBalance");
    ak.insert(false,"Is it a smaller American sports brand?","Reebok","Is it UnderArmour?");
    ak.insert(false,"Is it an American sports brand?","Nike","Is it a smaller American sports brand?");
    ak.insert(false,"Is it Adidas?","Adidas","Puma");
    ak.insert(false,"Is it a German sports brand?","Is it Adidas?","Is it an American sports brand?");
    ak.insert(false,"Is it sports brand?","Is it a German sports brand?","Is it retail company?");

    // ===== BEVERAGE BRANCH -> no chains to sports =====
    ak.insert(false,"Is its logo primarily red not blue?","CocaCola","Pepsi");
    ak.insert(false,"Is it a cola brand?","Is its logo primarily red not blue?","Starbucks");
    ak.insert(false,"Is it an energy drink?","RedBull","Heineken");
    ak.insert(false,"Is it alcoholic or energy based?","Is it an energy drink?","Nescafe");
    ak.insert(false,"Is it a cola or coffee brand?","Is it a cola brand?","Is it alcoholic or energy based?");
    ak.insert(false,"Is it beverage company?","Is it a cola or coffee brand?","Is it sports brand?");

    // ===== AUTOMOBILE BRANCH -> no chains to beverage =====
    ak.insert(false,"Is it an Italian car brand?","Ferrari","Volkswagen");
    ak.insert(false,"Is it a German car brand?","BMW","Is it an Italian car brand?");
    ak.insert(false,"Is it Mercedes?","Mercedes","Is it a German car brand?");
    ak.insert(false,"Is it a European car brand?","Is it Mercedes?","Ford");
    ak.insert(false,"Is it a Japanese car brand?","Toyota","Honda");
    ak.insert(false,"Is it an Asian car brand?","Is it a Japanese car brand?","Is it a European car brand?");
    ak.insert(false,"Is it electric vehicle focused?","Tesla","Is it an Asian car brand?");
    ak.insert(false,"Is it automobile company?","Is it electric vehicle focused?","Is it beverage company?");

    // ===== TECH BRANCH -> no chains to automobile =====
    ak.insert(false,"Is it Nvidia?","Nvidia","AMD");
    ak.insert(false,"Is it a chip maker?","Is it Nvidia?","Intel");
    ak.insert(false,"Is it Dell?","Dell","IBM");
    ak.insert(false,"Is it a PC or enterprise hardware brand?","Is it Dell?","Is it a chip maker?");
    ak.insert(false,"Is it a search engine company?","Google","Microsoft");
    ak.insert(false,"Is it software or search focused?","Is it a search engine company?","Is it a PC or enterprise hardware brand?");
    ak.insert(false,"Is it American hardware company?","Apple","Is it software or search focused?");
    ak.insert(false,"Is it a Japanese electronics brand?","Sony","Samsung");
    ak.insert(false,"Is it an Asian electronics brand?","Is it a Japanese electronics brand?","Is it American hardware company?");
    ak.insert(false,"Is it a tech company?","Is it an Asian electronics brand?","Is it automobile company?");

    // ROOT
    ak.set_root("Is it a tech company?");

    cout << "\nAnswer Yes or No.\n\n";
    ak.traverse();
    return 0;
}
