#include "Akinator.h"
#include <strings.h>

using namespace std;

Akinator::Akinator() {
    root = nullptr;
}

void Akinator::traverse() {
    traverse_helper(root);
}

void Akinator::traverse_helper(Node* node) {

    if(node->yes == nullptr && node->no == nullptr) {
        cout << "Your company is: " << node->question << endl;
        return;
    }

    if(ask(node))
        traverse_helper(node->yes);
    else
        traverse_helper(node->no);
}

bool Akinator::ask(Node* node) {

    cout << node->question << " (Yes/No): ";

    string ans;
    cin >> ans;

    return (strcasecmp(ans.c_str(),"yes") == 0);
}

void Akinator::insert(bool answer, string question, string y, string n) {

    Node* yesNode = nodeMap[y];
    Node* noNode  = nodeMap[n];

    Node* newNode = new Node(answer, question, yesNode, noNode);
    nodeMap[question] = newNode;
}

void Akinator::insert_answer(bool answer, string question, Node* y, Node* n) {

    Node* newNode = new Node(answer, question, y, n);
    nodeMap[question] = newNode;
}

void Akinator::set_root(string start) {
    root = nodeMap[start];
}
