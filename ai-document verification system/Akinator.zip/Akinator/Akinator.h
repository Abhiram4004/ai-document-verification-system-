#ifndef AKINATOR_H
#define AKINATOR_H

#include <iostream>
#include <string>
#include <unordered_map>

class Akinator {

private:

    struct Node {
        bool answer;
        std::string question;
        Node* yes;
        Node* no;

        Node(bool a, std::string q, Node* y, Node* n)
            : answer(a), question(q), yes(y), no(n) {}
    };

    Node* root;
    std::unordered_map<std::string, Node*> nodeMap;

    void traverse_helper(Node* node);

public:

    Akinator();

    bool ask(Node* node);
    void traverse();

    void insert(bool answer, std::string question, std::string y, std::string n);
    void insert_answer(bool answer, std::string question, Node* y, Node* n);

    void set_root(std::string start);
};

#endif
